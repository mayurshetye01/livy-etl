import logging.config


class NCDataHubLogging:
    __config = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'verbose': {
                'format': '%(levelname)s | %(asctime)s | %(module)s | %(message)s'
            },
            'simple': {
                'format': '%(levelname)s | %(message)s'
            },
        },
        'handlers': {
            'console': {
                'level': 'INFO',
                'class': 'logging.StreamHandler',
                'formatter': 'verbose'
            },
            'file': {
                'level': 'INFO',
                'class': 'logging.handlers.RotatingFileHandler',
                'formatter': 'verbose',
                'filename': 'application.log',
                'maxBytes': 1024
            },
        },
        'loggers': {
            '': {  # root logger
                'handlers': ['console', 'file'],
                'level': 'INFO',
                'propagate': False
            },
        }
    }

    __initialized = False

    def __init__(self):
        # Run only once at startup
        logging.config.dictConfig(self.__config)
        self.__initialized = True

    @staticmethod
    def get_logger(name):
        if not NCDataHubLogging.__initialized:
            NCDataHubLogging()
        return logging.getLogger(name)
