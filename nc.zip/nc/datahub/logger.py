import logging


class DataHubLogger(logging.getLoggerClass()):
    def __init__(self,
                 name,
                 format="%(asctime)s %(levelname)s %(module)s: %(message)s",
                 date_format="%y/%m/%d %H:%M:%S",
                 level=logging.INFO):
        # Initial
        self.format = format
        self.level = level
        self.name = name
        self.date_format = date_format

        # create logger
        logger = logging.getLogger(name)
        logger.setLevel(self.level)

        # Create file handler
        fh = logging.FileHandler('dh_logger.log')
        fh.setLevel(self.level)

        # create console handler
        ch = logging.StreamHandler()
        ch.setLevel(self.level)

        # create formatter and add it to the handlers
        formatter = logging.Formatter(self.format, self.date_format)
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)

        # add the handlers to the logger
        logger.addHandler(fh)
        logger.addHandler(ch)

        self.logger = logger

    # Can override base methods
    def info(self, msg, extra=None):
        self.logger.info(msg, extra=extra)

    def error(self, msg, extra=None):
        self.logger.error(msg, extra=extra)

    def debug(self, msg, extra=None):
        self.logger.debug(msg, extra=extra)

    def warn(self, msg, extra=None):
        self.logger.warning(msg, extra=extra)
